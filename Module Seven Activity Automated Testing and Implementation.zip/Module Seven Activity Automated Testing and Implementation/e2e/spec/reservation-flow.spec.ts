// ─── Assignment TODOs ────────────────────────────────────────────────────────
// TODO-5 [RC 3]: Complete the E2E reservation workflow test
// ─────────────────────────────────────────────────────────────────────────────

// ─── Playwright UI Testing Patterns ──────────────────────────────────────────
// page.goto("/path")                            — navigate to a URL
// page.getByRole("article")                     — find element by ARIA role
//   .filter({ hasText: "text" })                — narrow down by text content
// page.getByRole("button", { name: /text/i })   — find button by label
// page.getByLabel("Label")                      — find input by its <label>
// element.fill("value")                         — type text into an input
// element.click()                               — click an element
// await expect(element).toBeVisible()           — assert element is visible
// await expect(element).toContainText("text")   — assert element contains text
// ─────────────────────────────────────────────────────────────────────────────

// ─── More Locator Examples ──────────────────────────────────────────────────
// Find a button inside a specific element:
//   card.getByRole("button", { name: /some text/i }).click()
// Find an input by its label and type into it:
//   page.getByLabel("First Name").fill("Alice")
// Find a visible status/alert region:
//   page.getByRole("status")
// Use regex for flexible button matching:
//   page.getByRole("button", { name: /back|browse/i })
// Find a table row by its content:
//   page.getByRole("row").filter({ hasText: "some text" })
// Assert an element is NOT visible (e.g., after deletion):
//   await expect(element).not.toBeVisible()
// ─────────────────────────────────────────────────────────────────────────────

import { test, expect } from "@playwright/test";
import { createMeetupViaApi } from "./helpers.ts";

// ─── Worked Example ─────────────────────────────────────────────────────────
// This test is fully implemented so you can study the patterns before writing
// your own test below.
// ─────────────────────────────────────────────────────────────────────────────

test.describe("Example: Meetup CRUD Workflow", () => {
  test("create, edit, and delete a meetup via the admin page", async ({ page }) => {
    // ── Step 1: Navigate to the Meetups admin page ──
    await page.goto("/meetups");

    // ── Step 2: Open the "Add Meetup" form and fill it in ──
    const meetupTitle = `CRUD Test ${Date.now()}`;
    await page.getByRole("button", { name: /add meetup/i }).click();
    await page.getByLabel("Title").fill(meetupTitle);
    await page.getByLabel("Description").fill("A test meetup");
    await page.getByLabel("Date").fill("2026-09-15");
    await page.getByLabel("Location").fill("Room 101");
    await page.getByLabel("Capacity").fill("20");
    await page.getByRole("button", { name: /save/i }).click();

    // ── Step 3: Verify the meetup appears in the table ──
    const row = page.getByRole("row").filter({ hasText: meetupTitle });
    await expect(row).toBeVisible();
    await expect(row).toContainText("20");

    // ── Step 4: Edit the meetup title ──
    await row.getByRole("button", { name: /edit/i }).click();
    await page.getByLabel("Title").fill(`${meetupTitle} (edited)`);
    await page.getByRole("button", { name: /save/i }).click();

    // ── Step 5: Verify the updated title appears ──
    const updatedRow = page.getByRole("row").filter({
      hasText: `${meetupTitle} (edited)`,
    });
    await expect(updatedRow).toBeVisible();

    // ── Step 6: Delete the meetup and verify it's gone ──
    await updatedRow.getByRole("button", { name: /delete/i }).click();
    await expect(updatedRow).not.toBeVisible();
  });
});

test.describe("Reservation Flow E2E", () => {
  test("full reservation workflow: browse, select, register, see confirmation", async ({ page }) => {
    // ── Setup: create a meetup via the API so we have data to work with ──
    const meetupTitle = `E2E Meetup ${Date.now()}`;
    await createMeetupViaApi(page, {
      title: meetupTitle,
      description: "End-to-end test meetup",
      date: "2026-08-01",
      location: "Test Venue",
      capacity: 10,
    });

    // ── Step 1: Navigate to the Register page ──
    await page.goto("/register");

    // ── Step 2: Find the meetup card and verify it shows spots ──
    const meetupCard = page.getByRole("article").filter({ hasText: meetupTitle });
    await expect(meetupCard).toBeVisible();
    await expect(meetupCard).toContainText("10");

    // TODO-5a: Click the "Reserve a Spot" button on the meetup card.
    //          Hint: find the button within meetupCard using its visible text.
    await meetupCard.getByRole("button", { name: /reserve a spot/i }).click();

    // TODO-5b: Fill in the registration form with a name and email, then submit.
    //          Hint: find inputs by their label text, fill them in, then click
    //          the submit button.
    await page.getByLabel("Name").fill("Taylor Tester");
    await page.getByLabel("Email").fill("taylor@test.com");
    await page.getByRole("button", { name: /^register$/i }).click();

    // TODO-5c: Verify the confirmation message appears and contains the
    //          meetup title.
    //          Hint: look for a status region and use toBeVisible() and
    //          toContainText().
    const confirmation = page.getByRole("status");
    await expect(confirmation).toBeVisible();
    await expect(confirmation).toContainText(meetupTitle);

    // TODO-5d: Navigate back to the meetup list and verify spots decreased
    //          from 10 to 9.
    //          Hint: click the back/browse button, find the card again, and
    //          check its text (see Step 2 above for the pattern).
    await page.getByRole("button", { name: /back to browse/i }).click();
    const updatedCard = page.getByRole("article").filter({ hasText: meetupTitle });
    await expect(updatedCard).toBeVisible();
    await expect(updatedCard).toContainText("9 of 10 spots left");
  });
});
