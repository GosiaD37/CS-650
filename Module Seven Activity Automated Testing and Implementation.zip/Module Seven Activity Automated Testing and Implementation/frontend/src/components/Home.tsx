import { useEffect, useState } from "react";
import { meetups } from "../api.ts";
import type { MeetupSummary } from "../types.ts";

export default function Home() {
  const [list, setList] = useState<MeetupSummary[]>([]);

  useEffect(() => {
    void meetups.list().then(setList);
  }, []);

  const totalSpots = list.reduce((sum, m) => sum + m.spotsLeft, 0);

  return (
    <div className="max-w-2xl mx-auto text-center space-y-6">
      <h1 className="text-3xl font-bold text-indigo-800">Welcome to React Meetup</h1>
      <p className="text-gray-600">
        Your local React developer community. Browse upcoming meetups, reserve your spot, and
        connect with fellow developers.
      </p>
      <div className="flex justify-center gap-8 mt-8">
        <div className="bg-white rounded-lg shadow p-6 w-40">
          <div className="text-3xl font-bold text-indigo-600">{list.length}</div>
          <div className="text-sm text-gray-500 mt-1">Upcoming Meetups</div>
        </div>
        <div className="bg-white rounded-lg shadow p-6 w-40">
          <div className="text-3xl font-bold text-indigo-600">{totalSpots}</div>
          <div className="text-sm text-gray-500 mt-1">Spots Available</div>
        </div>
      </div>
    </div>
  );
}
