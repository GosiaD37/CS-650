import { useEffect, useState } from "react";
import { meetups as api, reservations as resApi } from "../api.ts";
import type { MeetupSummary, MeetupWithDetails, Reservation } from "../types.ts";

interface MeetupForm {
  title: string;
  description: string;
  date: string;
  location: string;
  capacity: string;
}

const emptyForm: MeetupForm = { title: "", description: "", date: "", location: "", capacity: "" };

export default function Meetups() {
  const [list, setList] = useState<MeetupSummary[]>([]);
  const [editing, setEditing] = useState<number | "new" | null>(null);
  const [form, setForm] = useState<MeetupForm>(emptyForm);
  const [viewing, setViewing] = useState<MeetupWithDetails | null>(null);
  const [viewReservations, setViewReservations] = useState<Reservation[]>([]);
  const [error, setError] = useState("");

  const reload = () => void api.list().then(setList);
  useEffect(reload, []);

  function openCreate() {
    setForm(emptyForm);
    setEditing("new");
    setError("");
  }

  async function openEdit(m: MeetupSummary) {
    setEditing(m.id);
    setError("");
    const full = await api.get(m.id);
    setForm({
      title: full.title,
      description: full.description,
      date: full.date,
      location: full.location,
      capacity: String(full.capacity),
    });
  }

  async function openView(m: MeetupSummary) {
    const [full, rsvps] = await Promise.all([api.get(m.id), resApi.list(m.id)]);
    setViewing(full);
    setViewReservations(rsvps);
  }

  async function handleSave() {
    try {
      const data = {
        title: form.title,
        description: form.description,
        date: form.date,
        location: form.location,
        capacity: Number(form.capacity),
      };
      if (editing === "new") {
        await api.create(data);
      } else if (typeof editing === "number") {
        await api.update(editing, data);
      }
      setEditing(null);
      reload();
    } catch (err) {
      setError((err as Error).message);
    }
  }

  async function handleDelete(id: number) {
    await api.delete(id);
    reload();
  }

  return (
    <div className="max-w-4xl mx-auto space-y-4">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-indigo-800">Meetups</h1>
        <button
          onClick={openCreate}
          className="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700 text-sm"
        >
          Add Meetup
        </button>
      </div>

      <table className="w-full bg-white shadow rounded overflow-hidden">
        <thead className="bg-gray-100 text-left text-sm text-gray-600">
          <tr>
            <th className="px-4 py-2">Title</th>
            <th className="px-4 py-2">Date</th>
            <th className="px-4 py-2">Location</th>
            <th className="px-4 py-2">Capacity</th>
            <th className="px-4 py-2">Spots Left</th>
            <th className="px-4 py-2">Actions</th>
          </tr>
        </thead>
        <tbody>
          {list.map((m) => (
            <tr key={m.id} data-testid="meetup-row" className="border-t text-sm">
              <td className="px-4 py-2">{m.title}</td>
              <td className="px-4 py-2">{m.date}</td>
              <td className="px-4 py-2">{m.location}</td>
              <td className="px-4 py-2">{m.capacity}</td>
              <td className="px-4 py-2">{m.spotsLeft}</td>
              <td className="px-4 py-2 space-x-2">
                <button
                  onClick={() => void openView(m)}
                  className="text-indigo-600 hover:underline text-xs"
                >
                  View
                </button>
                <button
                  onClick={() => openEdit(m)}
                  className="text-indigo-600 hover:underline text-xs"
                >
                  Edit
                </button>
                <button
                  onClick={() => void handleDelete(m.id)}
                  className="text-red-600 hover:underline text-xs"
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Create / Edit Modal */}
      {editing !== null && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-10">
          <div data-testid="modal" className="bg-white rounded-lg shadow-lg p-6 w-full max-w-md space-y-4">
            <h2 className="text-lg font-bold">
              {editing === "new" ? "Add Meetup" : "Edit Meetup"}
            </h2>
            {error && <p className="text-red-600 text-sm">{error}</p>}
            <label className="block">
              <span className="text-sm font-medium">Title</span>
              <input
                className="mt-1 block w-full border rounded px-3 py-2 text-sm"
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
              />
            </label>
            <label className="block">
              <span className="text-sm font-medium">Description</span>
              <textarea
                className="mt-1 block w-full border rounded px-3 py-2 text-sm"
                rows={3}
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
              />
            </label>
            <label className="block">
              <span className="text-sm font-medium">Date</span>
              <input
                type="date"
                className="mt-1 block w-full border rounded px-3 py-2 text-sm"
                value={form.date}
                onChange={(e) => setForm({ ...form, date: e.target.value })}
              />
            </label>
            <label className="block">
              <span className="text-sm font-medium">Location</span>
              <input
                className="mt-1 block w-full border rounded px-3 py-2 text-sm"
                value={form.location}
                onChange={(e) => setForm({ ...form, location: e.target.value })}
              />
            </label>
            <label className="block">
              <span className="text-sm font-medium">Capacity</span>
              <input
                type="number"
                min="1"
                className="mt-1 block w-full border rounded px-3 py-2 text-sm"
                value={form.capacity}
                onChange={(e) => setForm({ ...form, capacity: e.target.value })}
              />
            </label>
            <div className="flex justify-end gap-2">
              <button
                onClick={() => setEditing(null)}
                className="px-4 py-2 text-sm text-gray-600 hover:text-gray-800"
              >
                Cancel
              </button>
              <button
                onClick={() => void handleSave()}
                className="bg-indigo-600 text-white px-4 py-2 rounded text-sm hover:bg-indigo-700"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}

      {/* View Detail Modal */}
      {viewing && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-10">
          <div data-testid="modal" className="bg-white rounded-lg shadow-lg p-6 w-full max-w-md space-y-4">
            <h2 className="text-lg font-bold">{viewing.title}</h2>
            <p className="text-sm text-gray-600">{viewing.description}</p>
            <div className="text-sm space-y-1">
              <p><strong>Date:</strong> {viewing.date}</p>
              <p><strong>Location:</strong> {viewing.location}</p>
              <p><strong>Capacity:</strong> {viewing.capacity}</p>
              <p><strong>Reservations:</strong> {viewing.reservationCount}</p>
              <p><strong>Spots Left:</strong> {viewing.spotsLeft}</p>
            </div>
            {viewReservations.length > 0 && (
              <div>
                <h3 className="text-sm font-semibold mt-2">Attendees</h3>
                <ul className="text-sm text-gray-600 list-disc pl-5">
                  {viewReservations.map((r) => (
                    <li key={r.id}>{r.name} ({r.email})</li>
                  ))}
                </ul>
              </div>
            )}
            <div className="flex justify-end">
              <button
                onClick={() => setViewing(null)}
                className="px-4 py-2 text-sm text-gray-600 hover:text-gray-800"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
