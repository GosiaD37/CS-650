import Database from "better-sqlite3";
import { Kysely, SqliteDialect, type Generated } from "kysely";

// ─── Table Types ─────────────────────────────────────────────────────────────

export interface MeetupTable {
  id: Generated<number>;
  title: string;
  description: string;
  date: string;
  location: string;
  capacity: number;
}

export interface ReservationTable {
  id: Generated<number>;
  meetup_id: number;
  name: string;
  email: string;
  created_at: Generated<string>;
}

export interface DatabaseSchema {
  meetups: MeetupTable;
  reservations: ReservationTable;
}

// ─── Setup ───────────────────────────────────────────────────────────────────

export type DB = Kysely<DatabaseSchema>;

const SCHEMA_SQL = `
  CREATE TABLE IF NOT EXISTS meetups (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    date TEXT NOT NULL,
    location TEXT NOT NULL,
    capacity INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS reservations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    meetup_id INTEGER NOT NULL REFERENCES meetups(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    email TEXT NOT NULL,
    created_at TEXT DEFAULT (datetime('now'))
  );
`;

export function openDb(path: string): DB {
  const sqlite = new Database(path);
  sqlite.pragma("foreign_keys = ON");
  sqlite.exec(SCHEMA_SQL);

  return new Kysely<DatabaseSchema>({
    dialect: new SqliteDialect({ database: sqlite }),
  });
}
