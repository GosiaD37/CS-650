import { openDb } from "./db.ts";
import { createMeetup } from "./service.ts";

const dbPath = process.env.DB_PATH ?? "meetup.db";
const db = openDb(dbPath);

const meetups = [
  {
    title: "React 19 Deep Dive",
    description: "Explore the latest features in React 19 including Server Components and Actions.",
    date: "2026-04-15",
    location: "Downtown Tech Hub, Room A",
    capacity: 30,
  },
  {
    title: "TypeScript Best Practices",
    description: "Learn advanced TypeScript patterns for scalable applications.",
    date: "2026-04-22",
    location: "Community Library, Meeting Room 2",
    capacity: 20,
  },
  {
    title: "Building with Vite",
    description: "Hands-on workshop for setting up and optimizing Vite-based projects.",
    date: "2026-05-06",
    location: "Startup Garage, Main Floor",
    capacity: 15,
  },
  {
    title: "Testing React Applications",
    description: "From unit tests to E2E: a comprehensive testing strategy for React apps.",
    date: "2026-05-13",
    location: "University Hall, Room 301",
    capacity: 25,
  },
  {
    title: "State Management Showdown",
    description: "Comparing Redux, Zustand, and React Context for state management.",
    date: "2026-06-03",
    location: "Co-Working Space, Floor 2",
    capacity: 10,
  },
];

for (const meetup of meetups) {
  await createMeetup(db, meetup);
}

console.log(`Seeded ${meetups.length} meetups.`);
