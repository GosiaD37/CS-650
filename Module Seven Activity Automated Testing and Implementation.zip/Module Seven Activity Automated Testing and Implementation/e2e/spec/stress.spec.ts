// ─── Assignment TODOs ────────────────────────────────────────────────────────
// TODO-6 [RC 4]: Complete the stress test assertions
// ─────────────────────────────────────────────────────────────────────────────

// ─── Playwright API Testing Patterns ─────────────────────────────────────────
// See api-integration.spec.ts for the full patterns reference.
// Key patterns used here:
// response.status()                     — returns the HTTP status code
// (await response.json()) as Type       — parses JSON with a type cast
// expect(value).toBe(expected)          — checks strict equality
// ─────────────────────────────────────────────────────────────────────────────

import { test, expect } from "@playwright/test";
import { createMeetupViaApi } from "./helpers.ts";

test.describe("Stress Test — Concurrent Reservations", () => {
  test("exactly N reservations succeed for a meetup with capacity N", async ({ page }) => {
    const CAPACITY = 10;

    const meetupId = await createMeetupViaApi(page, {
      title: `Stress Test Meetup ${Date.now()}`,
      description: "Stress test for concurrent reservations",
      date: "2026-09-01",
      location: "Load Test Room",
      capacity: CAPACITY,
    });

    // ── Fire CAPACITY + 5 concurrent reservation requests ──
    // Array.from() creates an array of N promises — one POST request per element.
    // Promise.all() sends them all at once (concurrently) and waits for all to
    // finish. Some will succeed (201) and some will be rejected (409) because the
    // meetup only has CAPACITY spots.
    const totalRequests = CAPACITY + 5;
    const promises = Array.from({ length: totalRequests }, (_, i) =>
      page.request.post(`/api/meetups/${meetupId}/reservations`, {
        data: {
          name: `User ${i}`,
          email: `user${i}@stress.test`,
        },
      }),
    );
    const responses = await Promise.all(promises);

    // TODO-6a: Count how many responses returned status 201 (success) and
    //          how many returned 409 (conflict/full).
    //          Hint: responses.map(r => r.status()) transforms each response
    //          into its status code. Then use .filter(s => s === 201).length
    //          to count how many matched.
    const statuses = responses.map((response) => response.status());
    const successes = statuses.filter((status) => status === 201).length;
    const conflicts = statuses.filter((status) => status === 409).length;

    // TODO-6b: Assert that exactly CAPACITY requests succeeded (201) and
    //          the rest were rejected (409).
    //          Hint: expect(successes).toBe(CAPACITY) and
    //          expect(conflicts).toBe(totalRequests - CAPACITY).
    expect(successes).toBe(CAPACITY);
    expect(conflicts).toBe(totalRequests - CAPACITY);

    // TODO-6c: Verify the final state by fetching the meetup details via
    //          GET /api/meetups/${meetupId} and asserting that
    //          reservationCount equals CAPACITY and spotsLeft equals 0.
    //          See MeetupWithDetails in backend/service.ts for response fields.
    //          Hint: see "GET /api/meetups/:id returns meetup details" in
    //          api-integration.spec.ts for the request pattern.
    const finalResponse = await page.request.get(`/api/meetups/${meetupId}`);
    expect(finalResponse.status()).toBe(200);
    const finalMeetup = (await finalResponse.json()) as { reservationCount: number; spotsLeft: number };
    expect(finalMeetup.reservationCount).toBe(CAPACITY);
    expect(finalMeetup.spotsLeft).toBe(0);
  });
});
