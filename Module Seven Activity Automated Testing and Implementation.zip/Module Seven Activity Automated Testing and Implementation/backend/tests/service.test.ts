// ─── Assignment TODOs ────────────────────────────────────────────────────────
// TODO-1 [RC 1]: Implement the stubbed happy-path unit tests
// TODO-2 [RC 1]: Implement the stubbed edge-case unit tests
// ─────────────────────────────────────────────────────────────────────────────

// ─── Testing Patterns ────────────────────────────────────────────────────────
// assert.equal(actual, expected)     — checks strict equality
// assert.ok(value)                   — checks value is truthy
// assert.rejects(fn, /pattern/i)    — checks that fn throws an error whose
//                                     message contains "pattern"
//                                     (the /i flag makes it case-insensitive)
// ─────────────────────────────────────────────────────────────────────────────

// ─── Service Functions ──────────────────────────────────────────────────────
// All functions tested below are defined in ../service.ts.
// Open that file to see each function's parameters and return types.
// ─────────────────────────────────────────────────────────────────────────────

import { describe, it, before } from "node:test";
import assert from "node:assert/strict";
import { freshDb, type DB } from "./helpers.ts";
import {
  createMeetup,
  getMeetup,
  listMeetups,
  updateMeetup,
  deleteMeetup,
  createReservation,
  listReservations,
} from "../service.ts";

// ─── createMeetup ───────────────────────────────────────────────────────────

describe("createMeetup", () => {
  let db: DB;
  before(() => { db = freshDb(); });

  // TODO-1a: Verify that creating a meetup returns the correct fields.
  //          Steps:
  //          1. Call createMeetup() with valid data (title, description, etc.)
  //          2. Assert the returned object has a positive id
  //          3. Assert title, description, date, location, and capacity match
  //          Hint: see "updates meetup fields correctly" in updateMeetup below.
  it("creates a meetup and returns it with correct fields", async () => {
    const data = {
      title: "React Testing Meetup",
      description: "Practice automated testing",
      date: "2026-05-01",
      location: "Room A",
      capacity: 25,
    };
    const meetup = await createMeetup(db, data);
    assert.ok(meetup.id > 0);
    assert.equal(meetup.title, data.title);
    assert.equal(meetup.description, data.description);
    assert.equal(meetup.date, data.date);
    assert.equal(meetup.location, data.location);
    assert.equal(meetup.capacity, data.capacity);
  });

  it("throws when capacity is zero or negative", async () => {
    await assert.rejects(
      () => createMeetup(db, {
        title: "Bad Meetup",
        description: "Desc",
        date: "2026-05-01",
        location: "Room A",
        capacity: 0,
      }),
      /capacity/i,
    );
  });

  // TODO-2a: Verify that createMeetup throws when given an empty title.
  //          Steps:
  //          1. Call createMeetup() with title: ""
  //          2. Assert it throws using assert.rejects(..., /title/i)
  //          Hint: see "throws when capacity is zero or negative" above.
  it("throws when title is empty", async () => {
    await assert.rejects(
      () => createMeetup(db, {
        title: "",
        description: "Desc",
        date: "2026-05-01",
        location: "Room A",
        capacity: 10,
      }),
      /title/i,
    );
  });
});

// ─── getMeetup ──────────────────────────────────────────────────────────────

describe("getMeetup", () => {
  let db: DB;
  before(() => { db = freshDb(); });

  // TODO-1b: Verify that getMeetup returns computed fields.
  //          Steps:
  //          1. Create a meetup with capacity 5
  //          2. Add a reservation via createReservation()
  //          3. Call getMeetup() and assert reservationCount is 1 and spotsLeft is 4
  //          Hint: see "returns all reservations for a meetup" in listReservations
  //          below for a similar create-then-query pattern.
  it("returns meetup with reservationCount and spotsLeft", async () => {
    const meetup = await createMeetup(db, {
      title: "Counts Meetup", description: "d", date: "2026-05-01", location: "X", capacity: 5,
    });
    await createReservation(db, meetup.id, { name: "Alice", email: "alice@test.com" });
    const result = await getMeetup(db, meetup.id);
    assert.ok(result);
    assert.equal(result.reservationCount, 1);
    assert.equal(result.spotsLeft, 4);
  });

  it("returns null for unknown id", async () => {
    assert.equal(await getMeetup(db, 99999), null);
  });
});

// ─── listMeetups ────────────────────────────────────────────────────────────

describe("listMeetups", () => {
  let db: DB;
  before(async () => {
    db = freshDb();
    await createMeetup(db, { title: "A", description: "d", date: "2026-05-01", location: "X", capacity: 10 });
    await createMeetup(db, { title: "B", description: "d", date: "2026-06-01", location: "Y", capacity: 20 });
  });

  it("returns all meetups with spotsLeft", async () => {
    const list = await listMeetups(db);
    assert.ok(list.length >= 2);
    assert.ok(list.every((m) => typeof m.spotsLeft === "number"));
  });
});

// ─── updateMeetup ───────────────────────────────────────────────────────────

describe("updateMeetup", () => {
  let db: DB;
  before(() => { db = freshDb(); });

  it("updates meetup fields correctly", async () => {
    const m = await createMeetup(db, {
      title: "Old",
      description: "Old desc",
      date: "2026-05-01",
      location: "Old place",
      capacity: 10,
    });
    const updated = await updateMeetup(db, m.id, {
      title: "New",
      description: "New desc",
      date: "2026-06-01",
      location: "New place",
      capacity: 30,
    });
    assert.equal(updated.title, "New");
    assert.equal(updated.description, "New desc");
    assert.equal(updated.capacity, 30);
  });

  // TODO-2b: Verify that updateMeetup throws when new capacity is less than
  //          current reservations.
  //          Steps:
  //          1. Create a meetup with capacity 2
  //          2. Add 2 reservations via createReservation()
  //          3. Try to update the meetup with capacity 1
  //          4. Assert it throws using assert.rejects(..., /capacity/i)
  //          Hint: see "throws when capacity is zero or negative" in createMeetup
  //          above for the assert.rejects pattern.
  it("throws when capacity is less than current reservations", async () => {
    const meetup = await createMeetup(db, { title: "Small", description: "d", date: "2026-05-01", location: "X", capacity: 2 });
    await createReservation(db, meetup.id, { name: "A", email: "a@test.com" });
    await createReservation(db, meetup.id, { name: "B", email: "b@test.com" });
    await assert.rejects(
      () => updateMeetup(db, meetup.id, { title: "Small", description: "d", date: "2026-05-01", location: "X", capacity: 1 }),
      /capacity/i,
    );
  });
});

// ─── deleteMeetup ───────────────────────────────────────────────────────────

describe("deleteMeetup", () => {
  let db: DB;
  before(() => { db = freshDb(); });

  it("removes the meetup", async () => {
    const m = await createMeetup(db, { title: "Temp", description: "d", date: "2026-05-01", location: "X", capacity: 5 });
    await deleteMeetup(db, m.id);
    assert.equal(await getMeetup(db, m.id), null);
  });
});

// ─── createReservation ──────────────────────────────────────────────────────

describe("createReservation", () => {
  let db: DB;
  before(() => { db = freshDb(); });

  // TODO-1c: Verify that createReservation returns the correct fields.
  //          Steps:
  //          1. Create a meetup
  //          2. Call createReservation() with { name, email }
  //          3. Assert r.id > 0, r.name and r.email match, r.meetup_id matches
  //          Hint: see "updates meetup fields correctly" in updateMeetup above
  //          for a similar create-then-assert pattern.
  it("creates a reservation and returns it with correct fields", async () => {
    const meetup = await createMeetup(db, { title: "Reservation Meetup", description: "d", date: "2026-05-01", location: "X", capacity: 10 });
    const reservation = await createReservation(db, meetup.id, { name: "Jordan", email: "jordan@test.com" });
    assert.ok(reservation.id > 0);
    assert.equal(reservation.name, "Jordan");
    assert.equal(reservation.email, "jordan@test.com");
    assert.equal(reservation.meetup_id, meetup.id);
  });

  // TODO-2c: Verify that createReservation throws when the meetup is full.
  //          Steps:
  //          1. Create a meetup with capacity 1
  //          2. Add one reservation
  //          3. Try to add a second reservation
  //          4. Assert it throws using assert.rejects(..., /full/i)
  //          Hint: see "throws when name is empty" below for the pattern.
  it("throws when meetup is at capacity", async () => {
    const meetup = await createMeetup(db, { title: "Full Meetup", description: "d", date: "2026-05-01", location: "X", capacity: 1 });
    await createReservation(db, meetup.id, { name: "First", email: "first@test.com" });
    await assert.rejects(
      () => createReservation(db, meetup.id, { name: "Second", email: "second@test.com" }),
      /full/i,
    );
  });

  it("throws when name is empty", async () => {
    const m = await createMeetup(db, { title: "M", description: "d", date: "2026-05-01", location: "X", capacity: 10 });
    await assert.rejects(
      () => createReservation(db, m.id, { name: "", email: "a@b.com" }),
      /name/i,
    );
  });
});

// ─── listReservations ───────────────────────────────────────────────────────

describe("listReservations", () => {
  let db: DB;
  before(() => { db = freshDb(); });

  it("returns all reservations for a meetup", async () => {
    const m = await createMeetup(db, { title: "M", description: "d", date: "2026-05-01", location: "X", capacity: 10 });
    await createReservation(db, m.id, { name: "A", email: "a@test.com" });
    await createReservation(db, m.id, { name: "B", email: "b@test.com" });
    const list = await listReservations(db, m.id);
    assert.equal(list.length, 2);
  });
});
