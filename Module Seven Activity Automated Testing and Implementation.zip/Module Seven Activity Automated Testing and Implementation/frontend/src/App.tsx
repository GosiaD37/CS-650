import { Outlet, NavLink } from "react-router";

export default function App() {
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <nav className="bg-indigo-700 text-white px-6 py-3 flex items-center gap-6 shadow">
        <span className="font-bold text-lg mr-4">React Meetup</span>
        <NavLink
          to="/"
          end
          className={({ isActive }) =>
            `text-sm hover:underline ${isActive ? "font-semibold underline" : ""}`
          }
        >
          Home
        </NavLink>
        <NavLink
          to="/meetups"
          className={({ isActive }) =>
            `text-sm hover:underline ${isActive ? "font-semibold underline" : ""}`
          }
        >
          Meetups
        </NavLink>
        <NavLink
          to="/register"
          className={({ isActive }) =>
            `text-sm hover:underline ${isActive ? "font-semibold underline" : ""}`
          }
        >
          Register
        </NavLink>
      </nav>
      <main className="flex-1 p-6">
        <Outlet />
      </main>
    </div>
  );
}
