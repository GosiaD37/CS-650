import type { Page } from "@playwright/test";

export interface MeetupInput {
  title: string;
  description: string;
  date: string;
  location: string;
  capacity: number;
}

export interface ReservationInput {
  name: string;
  email: string;
}

export async function createMeetupViaApi(
  page: Page,
  meetup: MeetupInput,
): Promise<number> {
  const response = await page.request.post("/api/meetups", { data: meetup });
  const body = (await response.json()) as { id: number };
  return body.id;
}

export async function createReservationViaApi(
  page: Page,
  meetupId: number,
  reservation: ReservationInput,
): Promise<number> {
  const response = await page.request.post(`/api/meetups/${meetupId}/reservations`, {
    data: reservation,
  });
  const body = (await response.json()) as { id: number };
  return body.id;
}
