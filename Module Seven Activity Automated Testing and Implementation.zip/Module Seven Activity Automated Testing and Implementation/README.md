# React Meetup — Testing

**Course:** CS 650 - Module 7-1

> **Open this folder in VS Code** using **File > Open Folder** and select the `module-7-1-react-meetup` directory. This gives you the full project structure in the sidebar. To read this README with formatting, right-click the file and choose **Open Preview**.

## Getting Started

```bash
# Terminal 1 — backend (port 3000)
cd backend && npm install && node seed.ts && node server.ts

# Terminal 2 — frontend (port 5173)
cd frontend && npm install && npm run dev
```

## Running

> These commands skip the one-time install and database seed.
> If you need to reset your data, see the **Database** section below.

```bash
# Terminal 1 — backend (port 3000)
cd backend && node server.ts

# Terminal 2 — frontend (port 5173)
cd frontend && npm run dev
```

## Database

The database (`backend/meetup.db`) is created and seeded during first-time setup. It persists across server restarts.

To reset the database to its original state, delete the file and re-seed:

```bash
cd backend && rm -f meetup.db && node seed.ts
```

## Running the Tests

```bash
# First time only — install E2E dependencies
cd e2e && npm install && npx playwright install chromium

# Backend unit tests
cd backend && npm test

# E2E tests (stop your dev servers first — Playwright starts its own)
cd e2e && npx playwright test
```

## Overview

This is a meetup management app where organizers create meetups and attendees register for them. The backend enforces capacity limits — reservations cannot exceed a meetup's capacity. The application and all tests are provided; your task is to implement the stubbed test cases.

## Testing

There are four test files to complete, each targeting a different testing level:

1. **Unit tests** (`backend/tests/service.student.test.ts`) — Test backend service functions directly using Node's built-in test runner. Each test gets a fresh in-memory SQLite database.

2. **API integration tests** (`e2e/spec/api-integration.student.spec.ts`) — Test HTTP endpoints via Playwright's `page.request` API. Verify status codes and response shapes.

3. **E2E workflow test** (`e2e/spec/reservation-flow.student.spec.ts`) — Test the full reservation UI workflow: browse meetups, select one, fill the form, and verify confirmation. A fully implemented CRUD example test is provided for reference.

4. **Stress test** (`e2e/spec/stress.student.spec.ts`) — Fire concurrent reservation requests and verify that exactly N succeed for a meetup with capacity N.

Look for `TODO` comments in each file — they describe what to implement and include step-by-step hints. Reference tests (without `.student.` in the filename) contain the full implementations.

## Assignment Tasks

| # | Task | File | RC |
|---|------|------|----|
| TODO-1 | Write unit tests for the core service functions (createMeetup, getMeetup, listMeetups, updateMeetup, deleteMeetup, createReservation, listReservations). Use the freshDb() helper that creates an in-memory SQLite database for each describe block. Cover the happy path for each function and verify returned fields match the input data.
 | `backend/tests/service.test.ts` | RC 1 |
| TODO-2 | Add negative and edge-case tests for the service functions. For example, verify that createMeetup rejects an empty title and zero/negative capacity, that createReservation rejects when the meetup is full or the name is empty, that getMeetup returns null for a non-existent id, and that updateMeetup rejects a capacity below the current reservation count.
 | `backend/tests/service.test.ts` | RC 1 |
| TODO-3 | Write Playwright integration tests that exercise the REST API endpoints. For each endpoint verify the HTTP method, expected status code, and response shape: POST /api/meetups (201), GET /api/meetups (200 with spotsLeft), GET /api/meetups/:id (200 with details), POST /api/meetups/:id/reservations (201), and GET /api/meetups/:id/reservations (200).
 | `e2e/spec/api-integration.spec.ts` | RC 2 |
| TODO-4 | Add negative integration tests that verify error responses: GET for a non-existent meetup returns 404, POST with invalid data returns 400 with an error message, and POST a reservation on a full meetup returns 409.
 | `e2e/spec/api-integration.spec.ts` | RC 2 |
| TODO-5 | Write an end-to-end Playwright test that performs the full reservation workflow through the browser: navigate to the Register page, locate a meetup card, click Reserve, fill in the name and email fields, submit the form, verify the confirmation message appears, then navigate back and verify the available spots decreased by one.
 | `e2e/spec/reservation-flow.spec.ts` | RC 3 |
| TODO-6 | Write a lightweight stress test that fires concurrent reservation requests against a meetup with a known capacity (e.g. 10). Send more requests than the capacity simultaneously using Promise.all. Assert that exactly N succeed (201) and the rest are rejected (409), and verify via the API that the final reservationCount equals the capacity and spotsLeft is zero.
 | `e2e/spec/stress.spec.ts` | RC 4 |

## Rubric Criteria

| RC | Description | Coding |
|----|-------------|--------|
| RC 1 | Implement unit tests for backend logic. Include unit tests targeting core backend functions, coverage of a negative or edge case, what these tests verify and why it matters for the application, and evidence of test execution.
 | Yes |
| RC 2 | Implement integration tests for API endpoints. Include integration tests that validate endpoint behavior, the endpoint method and expected status code and response shape for each test, what these tests verify and why it matters for the application, and evidence of test execution.
 | Yes |
| RC 3 | Implement an end-to-end test for a key workflow. Include the user actions or steps the test performs and what the workflow is intended to confirm, why this workflow is important to test, and evidence of test execution.
 | Yes |
| RC 4 | Execute a basic non-functional stress test. Include the stress test parameters used, what the stress test is intended to reveal about the application, and evidence of results.
 | Yes |
| RC 5 | Summarize your test coverage and results. Include what risk, requirement, or workflow each test connects to in the application, how your functional test results support application correctness and how your stress test results relate to reliability and performance, and why your evidence supports release readiness and any gaps or areas you would prioritize for additional testing.
 | No |
