import express from "express";
import { z } from "zod";
import { openDb } from "./db.ts";
import { securityHeaders, rateLimiter, requestLogger } from "./middleware.ts";
import {
  createMeetup,
  getMeetup,
  listMeetups,
  updateMeetup,
  deleteMeetup,
  createReservation,
  listReservations,
} from "./service.ts";

// ─── DB ──────────────────────────────────────────────────────────────────────

const dbPath = process.env.DB_PATH ?? "meetup.db";
const db = openDb(dbPath);

// ─── Schemas ─────────────────────────────────────────────────────────────────

const MeetupBodySchema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string().min(1, "Description is required"),
  date: z.string().min(1, "Date is required"),
  location: z.string().min(1, "Location is required"),
  capacity: z.number().int().positive("Capacity must be a positive integer"),
});

const ReservationBodySchema = z.object({
  name: z.string().min(1, "Name is required"),
  email: z.email("Valid email is required"),
});

// ─── App ─────────────────────────────────────────────────────────────────────

const app = express();
app.use(express.json());
app.use(securityHeaders());
app.use(rateLimiter());
app.use(requestLogger());

// ─── Meetups ─────────────────────────────────────────────────────────────────

app.get("/api/meetups", async (_req, res) => {
  res.json(await listMeetups(db));
});

app.get("/api/meetups/:id", async (req, res) => {
  const meetup = await getMeetup(db, Number(req.params.id));
  if (!meetup) {
    res.status(404).json({ error: "Not found" });
    return;
  }
  res.json(meetup);
});

app.post("/api/meetups", async (req, res) => {
  const result = MeetupBodySchema.safeParse(req.body);
  if (!result.success) {
    res.status(400).json({ error: result.error.issues.map((i) => i.message).join("; ") });
    return;
  }
  res.status(201).json(await createMeetup(db, result.data));
});

app.put("/api/meetups/:id", async (req, res) => {
  const result = MeetupBodySchema.safeParse(req.body);
  if (!result.success) {
    res.status(400).json({ error: result.error.issues.map((i) => i.message).join("; ") });
    return;
  }
  try {
    res.json(await updateMeetup(db, Number(req.params.id), result.data));
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

app.delete("/api/meetups/:id", async (req, res) => {
  await deleteMeetup(db, Number(req.params.id));
  res.status(204).send();
});

// ─── Reservations ────────────────────────────────────────────────────────────

app.post("/api/meetups/:id/reservations", async (req, res) => {
  const result = ReservationBodySchema.safeParse(req.body);
  if (!result.success) {
    res.status(400).json({ error: result.error.issues.map((i) => i.message).join("; ") });
    return;
  }
  try {
    const reservation = await createReservation(db, Number(req.params.id), result.data);
    res.status(201).json(reservation);
  } catch (err) {
    const message = (err as Error).message;
    if (message === "Meetup is full") {
      res.status(409).json({ error: message });
    } else if (message === "Meetup not found") {
      res.status(404).json({ error: message });
    } else {
      res.status(400).json({ error: message });
    }
  }
});

app.get("/api/meetups/:id/reservations", async (req, res) => {
  res.json(await listReservations(db, Number(req.params.id)));
});

// ─── Start ───────────────────────────────────────────────────────────────────

const port = Number(process.env.PORT ?? 3000);
app.listen(port, (err) => {
  if (err) {
    console.error("Failed to start server:", err);
    process.exit(1);
  }
  console.log(`Backend listening on http://localhost:${port}`);
});
