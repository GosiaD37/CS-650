// ─── Assignment TODOs ────────────────────────────────────────────────────────
// TODO-3 [RC 2]: Implement the stubbed happy-path integration tests
// TODO-4 [RC 2]: Implement the stubbed error-scenario integration test
// ─────────────────────────────────────────────────────────────────────────────

// ─── Playwright API Testing Patterns ─────────────────────────────────────────
// page.request.post(url, { data })      — sends a POST request
// page.request.get(url)                 — sends a GET request
// response.status()                     — returns the HTTP status code (e.g. 200)
// (await response.json()) as Type       — parses the JSON body with a type cast
// expect(value).toBe(expected)          — checks strict equality
// expect(value).toBeGreaterThan(n)      — checks value > n
// expect(value).toBeTruthy()            — checks value is truthy
// expect(obj).toHaveProperty("key")     — checks object has the given property
// expect(value).toMatch(/pattern/i)     — checks string matches a regex pattern
// createMeetupViaApi(page, data)        — helper that creates a meetup via POST
//                                         and returns its id
// ─────────────────────────────────────────────────────────────────────────────

import { test, expect } from "@playwright/test";
import { createMeetupViaApi } from "./helpers.ts";

test.describe("API Integration Tests", () => {
  const meetupData = {
    title: "Integration Test Meetup",
    description: "A meetup for testing",
    date: "2026-07-01",
    location: "Test Room",
    capacity: 5,
  };

  test("POST /api/meetups creates a meetup and returns 201", async ({ page }) => {
    const response = await page.request.post("/api/meetups", { data: meetupData });
    expect(response.status()).toBe(201);
    const body = (await response.json()) as { id: number; title: string };
    expect(body.title).toBe(meetupData.title);
    expect(body.id).toBeGreaterThan(0);
  });

  // TODO-3a: Verify GET /api/meetups returns a list with spotsLeft.
  //          Create a meetup first via createMeetupViaApi(), then GET the list.
  //          Assert status 200, body array is non-empty, and the first item
  //          has a "spotsLeft" property.
  //          See Meetup and MeetupSummary in backend/service.ts for response fields.
  //          Hint: see "POST /api/meetups creates a meetup" above for the
  //          request/status/JSON pattern.
  // The line below always fails — delete it and replace with your implementation
  test("GET /api/meetups lists meetups with spotsLeft", async ({ page }) => {
    await createMeetupViaApi(page, meetupData);
    const response = await page.request.get("/api/meetups");
    expect(response.status()).toBe(200);
    const body = (await response.json()) as Array<{ id: number; spotsLeft: number }>;
    expect(body.length).toBeGreaterThan(0);
    expect(body[0]).toHaveProperty("spotsLeft");
  });

  // TODO-3b: Verify GET /api/meetups/:id returns meetup details.
  //          Create a meetup via createMeetupViaApi() (it returns the id),
  //          then GET /api/meetups/${id}. Assert status 200 and verify
  //          title, reservationCount (0), and spotsLeft (5).
  //          See MeetupWithDetails in backend/service.ts for response fields.
  //          Hint: see "POST /api/meetups creates a meetup" above for the
  //          JSON type-cast pattern.
  test("GET /api/meetups/:id returns meetup details", async ({ page }) => {
    const id = await createMeetupViaApi(page, meetupData);
    const response = await page.request.get(`/api/meetups/${id}`);
    expect(response.status()).toBe(200);
    const body = (await response.json()) as { title: string; reservationCount: number; spotsLeft: number };
    expect(body.title).toBe(meetupData.title);
    expect(body.reservationCount).toBe(0);
    expect(body.spotsLeft).toBe(5);
  });

  test("GET /api/meetups/:id returns 404 for non-existent id", async ({ page }) => {
    const response = await page.request.get("/api/meetups/99999");
    expect(response.status()).toBe(404);
  });

  test("POST /api/meetups with invalid data returns 400", async ({ page }) => {
    const response = await page.request.post("/api/meetups", {
      data: { title: "", description: "", date: "", location: "", capacity: -1 },
    });
    expect(response.status()).toBe(400);
    const body = (await response.json()) as { error: string };
    expect(body.error).toBeTruthy();
  });

  // TODO-3c: Verify POST /api/meetups/:id/reservations creates a reservation.
  //          Create a meetup via createMeetupViaApi(), then POST a reservation
  //          with { name, email }. Assert status 201 and verify the response
  //          body has matching name and email.
  //          See Reservation in backend/service.ts for response fields.
  //          Hint: see "POST /api/meetups creates a meetup" above — same
  //          pattern but with a different URL and data shape.
  test("POST /api/meetups/:id/reservations creates reservation and returns 201", async ({ page }) => {
    const id = await createMeetupViaApi(page, meetupData);
    const response = await page.request.post(`/api/meetups/${id}/reservations`, {
      data: { name: "API User", email: "api.user@test.com" },
    });
    expect(response.status()).toBe(201);
    const body = (await response.json()) as { name: string; email: string; meetup_id: number };
    expect(body.name).toBe("API User");
    expect(body.email).toBe("api.user@test.com");
    expect(body.meetup_id).toBe(id);
  });

  // TODO-4a: Verify POST /api/meetups/:id/reservations returns 409 when full.
  //          Create a meetup with capacity 1, add one reservation, then try a
  //          second. Assert status 409 and verify the error message.
  //          The error response has shape { error: string }.
  //          Hint: see "POST /api/meetups with invalid data returns 400" above
  //          for the error response pattern.
  test("POST /api/meetups/:id/reservations returns 409 when full", async ({ page }) => {
    const id = await createMeetupViaApi(page, { ...meetupData, title: `Full API Meetup ${Date.now()}`, capacity: 1 });
    const first = await page.request.post(`/api/meetups/${id}/reservations`, {
      data: { name: "First", email: "first@test.com" },
    });
    expect(first.status()).toBe(201);
    const second = await page.request.post(`/api/meetups/${id}/reservations`, {
      data: { name: "Second", email: "second@test.com" },
    });
    expect(second.status()).toBe(409);
    const body = (await second.json()) as { error: string };
    expect(body.error).toMatch(/full/i);
  });
});
