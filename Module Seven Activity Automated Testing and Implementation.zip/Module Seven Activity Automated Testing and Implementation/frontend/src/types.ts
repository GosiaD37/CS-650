export interface Meetup {
  id: number;
  title: string;
  description: string;
  date: string;
  location: string;
  capacity: number;
}

export interface MeetupWithDetails extends Meetup {
  reservationCount: number;
  spotsLeft: number;
}

export interface MeetupSummary {
  id: number;
  title: string;
  date: string;
  location: string;
  capacity: number;
  spotsLeft: number;
}

export interface Reservation {
  id: number;
  meetup_id: number;
  name: string;
  email: string;
  created_at: string;
}
