import { useEffect, useState } from "react";
import { meetups as api, reservations as resApi } from "../api.ts";
import type { MeetupSummary } from "../types.ts";

type Mode = "browse" | "form" | "confirmed";

export default function Register() {
  const [list, setList] = useState<MeetupSummary[]>([]);
  const [mode, setMode] = useState<Mode>("browse");
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [selectedTitle, setSelectedTitle] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [error, setError] = useState("");

  const reload = () => void api.list().then(setList);
  useEffect(reload, []);

  function selectMeetup(m: MeetupSummary) {
    setSelectedId(m.id);
    setSelectedTitle(m.title);
    setName("");
    setEmail("");
    setError("");
    setMode("form");
  }

  async function handleRegister() {
    if (!selectedId) return;
    try {
      await resApi.create(selectedId, { name, email });
      setMode("confirmed");
    } catch (err) {
      setError((err as Error).message);
    }
  }

  function backToBrowse() {
    setMode("browse");
    setSelectedId(null);
    reload();
  }

  // ─── Browse ──────────────────────────────────────────────────────────────

  if (mode === "browse") {
    return (
      <div className="max-w-3xl mx-auto space-y-4">
        <h1 className="text-2xl font-bold text-indigo-800">Register for a Meetup</h1>
        <div className="grid gap-4 sm:grid-cols-2">
          {list.map((m) => (
            <article
              key={m.id}
              className="bg-white shadow rounded-lg p-4 flex flex-col justify-between"
            >
              <div>
                <h2 className="font-semibold text-indigo-700">{m.title}</h2>
                <p className="text-sm text-gray-500 mt-1">
                  {m.date} &middot; {m.location}
                </p>
                <p className="text-sm mt-2">
                  <span className="font-medium">{m.spotsLeft}</span> of {m.capacity} spots left
                </p>
              </div>
              <button
                onClick={() => selectMeetup(m)}
                disabled={m.spotsLeft === 0}
                className="mt-3 bg-indigo-600 text-white px-3 py-1.5 rounded text-sm hover:bg-indigo-700 disabled:bg-gray-300 disabled:cursor-not-allowed"
              >
                {m.spotsLeft === 0 ? "Full" : "Reserve a Spot"}
              </button>
            </article>
          ))}
        </div>
      </div>
    );
  }

  // ─── Form ────────────────────────────────────────────────────────────────

  if (mode === "form") {
    return (
      <div className="max-w-md mx-auto space-y-4">
        <h1 className="text-2xl font-bold text-indigo-800">Register for {selectedTitle}</h1>
        {error && <p className="text-red-600 text-sm">{error}</p>}
        <div className="bg-white shadow rounded-lg p-6 space-y-4">
          <label className="block">
            <span className="text-sm font-medium">Name</span>
            <input
              className="mt-1 block w-full border rounded px-3 py-2 text-sm"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </label>
          <label className="block">
            <span className="text-sm font-medium">Email</span>
            <input
              type="email"
              className="mt-1 block w-full border rounded px-3 py-2 text-sm"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </label>
          <div className="flex gap-2">
            <button
              onClick={backToBrowse}
              className="px-4 py-2 text-sm text-gray-600 hover:text-gray-800"
            >
              Back to Browse
            </button>
            <button
              onClick={() => void handleRegister()}
              className="bg-indigo-600 text-white px-4 py-2 rounded text-sm hover:bg-indigo-700"
            >
              Register
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ─── Confirmed ───────────────────────────────────────────────────────────

  return (
    <div className="max-w-md mx-auto space-y-4 text-center">
      <div role="status" className="bg-green-50 border border-green-200 rounded-lg p-6 space-y-2">
        <h2 className="text-xl font-bold text-green-800">You're registered!</h2>
        <p className="text-green-700">
          You have successfully reserved a spot for <strong>{selectedTitle}</strong>.
        </p>
      </div>
      <button
        onClick={backToBrowse}
        className="text-indigo-600 hover:underline text-sm"
      >
        Back to Browse
      </button>
    </div>
  );
}
