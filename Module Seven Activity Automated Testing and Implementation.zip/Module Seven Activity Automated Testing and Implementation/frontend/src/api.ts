import type { MeetupSummary, MeetupWithDetails, Meetup, Reservation } from "./types.ts";

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(path, {
    headers: { "Content-Type": "application/json" },
    ...init,
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error((body as { error?: string }).error ?? `HTTP ${res.status}`);
  }
  if (res.status === 204) return undefined as unknown as T;
  return res.json() as Promise<T>;
}

// ─── Meetups ─────────────────────────────────────────────────────────────────

export const meetups = {
  list: (): Promise<MeetupSummary[]> => request<MeetupSummary[]>("/api/meetups"),

  get: (id: number): Promise<MeetupWithDetails> =>
    request<MeetupWithDetails>(`/api/meetups/${id}`),

  create: (data: {
    title: string;
    description: string;
    date: string;
    location: string;
    capacity: number;
  }): Promise<Meetup> =>
    request<Meetup>("/api/meetups", {
      method: "POST",
      body: JSON.stringify(data),
    }),

  update: (
    id: number,
    data: {
      title: string;
      description: string;
      date: string;
      location: string;
      capacity: number;
    },
  ): Promise<Meetup> =>
    request<Meetup>(`/api/meetups/${id}`, {
      method: "PUT",
      body: JSON.stringify(data),
    }),

  delete: (id: number): Promise<void> =>
    request<void>(`/api/meetups/${id}`, { method: "DELETE" }),
};

// ─── Reservations ────────────────────────────────────────────────────────────

export const reservations = {
  create: (meetupId: number, data: { name: string; email: string }): Promise<Reservation> =>
    request<Reservation>(`/api/meetups/${meetupId}/reservations`, {
      method: "POST",
      body: JSON.stringify(data),
    }),

  list: (meetupId: number): Promise<Reservation[]> =>
    request<Reservation[]>(`/api/meetups/${meetupId}/reservations`),
};
