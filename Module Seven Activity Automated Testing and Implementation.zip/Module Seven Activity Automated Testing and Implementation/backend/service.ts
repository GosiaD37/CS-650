import { sql } from "kysely";
import type { DB } from "./db.ts";

// ─── Types ───────────────────────────────────────────────────────────────────

export interface Meetup {
  id: number;
  title: string;
  description: string;
  date: string;
  location: string;
  capacity: number;
}

export interface MeetupWithDetails extends Meetup {
  reservationCount: number;
  spotsLeft: number;
}

export interface MeetupSummary {
  id: number;
  title: string;
  date: string;
  location: string;
  capacity: number;
  spotsLeft: number;
}

export interface Reservation {
  id: number;
  meetup_id: number;
  name: string;
  email: string;
  created_at: string;
}

// ─── Meetups ─────────────────────────────────────────────────────────────────

export async function createMeetup(
  db: DB,
  data: { title: string; description: string; date: string; location: string; capacity: number },
): Promise<Meetup> {
  if (!data.title.trim()) throw new Error("Title is required");
  if (data.capacity <= 0) throw new Error("Capacity must be a positive number");

  const result = await db
    .insertInto("meetups")
    .values({
      title: data.title.trim(),
      description: data.description.trim(),
      date: data.date,
      location: data.location.trim(),
      capacity: data.capacity,
    })
    .returningAll()
    .executeTakeFirstOrThrow();

  return result as Meetup;
}

export async function getMeetup(db: DB, id: number): Promise<MeetupWithDetails | null> {
  const meetup = await db
    .selectFrom("meetups")
    .selectAll()
    .where("id", "=", id)
    .executeTakeFirst();

  if (!meetup) return null;

  const { count } = await db
    .selectFrom("reservations")
    .select(sql<number>`COUNT(*)`.as("count"))
    .where("meetup_id", "=", id)
    .executeTakeFirstOrThrow();

  return {
    ...(meetup as Meetup),
    reservationCount: Number(count),
    spotsLeft: meetup.capacity - Number(count),
  };
}

export async function listMeetups(db: DB): Promise<MeetupSummary[]> {
  const rows = await db
    .selectFrom("meetups as m")
    .leftJoin("reservations as r", "r.meetup_id", "m.id")
    .select([
      "m.id",
      "m.title",
      "m.date",
      "m.location",
      "m.capacity",
      sql<number>`m.capacity - COUNT(r.id)`.as("spotsLeft"),
    ])
    .groupBy("m.id")
    .orderBy("m.date")
    .execute();

  return rows as MeetupSummary[];
}

export async function updateMeetup(
  db: DB,
  id: number,
  data: { title: string; description: string; date: string; location: string; capacity: number },
): Promise<Meetup> {
  const { count } = await db
    .selectFrom("reservations")
    .select(sql<number>`COUNT(*)`.as("count"))
    .where("meetup_id", "=", id)
    .executeTakeFirstOrThrow();

  if (data.capacity < Number(count)) {
    throw new Error(`Capacity cannot be less than current reservations (${count})`);
  }

  await db
    .updateTable("meetups")
    .set({
      title: data.title.trim(),
      description: data.description.trim(),
      date: data.date,
      location: data.location.trim(),
      capacity: data.capacity,
    })
    .where("id", "=", id)
    .execute();

  const updated = await db
    .selectFrom("meetups")
    .selectAll()
    .where("id", "=", id)
    .executeTakeFirstOrThrow();

  return updated as Meetup;
}

export async function deleteMeetup(db: DB, id: number): Promise<void> {
  await db.deleteFrom("meetups").where("id", "=", id).execute();
}

// ─── Reservations ────────────────────────────────────────────────────────────

export async function createReservation(
  db: DB,
  meetupId: number,
  data: { name: string; email: string },
): Promise<Reservation> {
  if (!data.name.trim()) throw new Error("Name is required");
  if (!data.email.trim()) throw new Error("Email is required");

  return await db.transaction().execute(async (tx) => {
    const meetup = await tx
      .selectFrom("meetups")
      .select(["id", "capacity"])
      .where("id", "=", meetupId)
      .executeTakeFirst();

    if (!meetup) throw new Error("Meetup not found");

    const { count } = await tx
      .selectFrom("reservations")
      .select(sql<number>`COUNT(*)`.as("count"))
      .where("meetup_id", "=", meetupId)
      .executeTakeFirstOrThrow();

    if (Number(count) >= meetup.capacity) throw new Error("Meetup is full");

    const result = await tx
      .insertInto("reservations")
      .values({
        meetup_id: meetupId,
        name: data.name.trim(),
        email: data.email.trim(),
      })
      .returningAll()
      .executeTakeFirstOrThrow();

    return result as Reservation;
  });
}

export async function listReservations(db: DB, meetupId: number): Promise<Reservation[]> {
  const rows = await db
    .selectFrom("reservations")
    .selectAll()
    .where("meetup_id", "=", meetupId)
    .orderBy("created_at")
    .execute();

  return rows as Reservation[];
}
